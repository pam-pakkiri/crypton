"use client";

import { useEffect, useState } from "react";

interface TickerData {
  last: number;
  percentage: number;
  high: number;
  low: number;
}

export default function Home() {
  // --- State ---
  const [status, setStatus] = useState<string>("checking...");
  const [isOnline, setIsOnline] = useState<boolean>(false);
  const [botStatus, setBotStatus] = useState<string>("offline");
  const [balance, setBalance] = useState<number>(0);
  const [assets, setAssets] = useState<any[]>([]);
  const [positions, setPositions] = useState<any[]>([]);
  const [openOrders, setOpenOrders] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState<string>("positions");
  const [lastError, setLastError] = useState<string | null>(null);
  const [size, setSize] = useState("");
  const [isMounted, setIsMounted] = useState(false);

  // Config
  const [symbol, setSymbol] = useState<string>("BTC/USDT");
  const [leverage, setLeverage] = useState<number>(5);
  const [marginMode, setMarginMode] = useState<string>("isolated");
  const [risk, setRisk] = useState<number>(1);

  // Tickers for header
  const [tickers, setTickers] = useState<Record<string, TickerData>>({});
  const [orderBook, setOrderBook] = useState<{ bids: any[][], asks: any[][] }>({ bids: [], asks: [] });

  const handleManualOrder = async (side: "buy" | "sell") => {
    try {
      setLastError(null);
      if (!size || parseFloat(size) <= 0) {
        setLastError("Please enter a valid size");
        return;
      }

      console.log(`Placing manual ${side} order for ${size}...`);
      const res = await fetch("http://127.0.0.1:8000/bot/trade", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          symbol,
          side,
          amount: parseFloat(size),
          type: "market"
        }),
      });

      const data = await res.json();
      if (data.status === "success" || data.status === "started") {
        console.log("Order placed successfully");
        fetchStatus();
        setSize(""); // Clear size after success
      } else {
        setLastError(data.message || "Order failed");
      }
    } catch (e) {
      setLastError("Failed to place order. Connection error?");
    }
  };

  // --- API Calls ---
  const fetchStatus = async () => {
    try {
      console.log("Fetching status...");
      const res = await fetch("http://127.0.0.1:8000/bot/status");
      if (res.ok) {
        const data = await res.json();
        console.log("Status received:", data.bot_status);
        setBotStatus(data.bot_status);
        setBalance(data.balance);
        setAssets(data.assets || []);
        setPositions(data.positions || []);
        setOpenOrders(data.open_orders || []);
        if (data.config) {
          // Sync local state with bot config if it changed externally
          // and we are NOT currently dragging/typing?
          // For now, simple overwrite
          setSymbol(data.config.symbol);
          setLeverage(data.config.leverage);
          setMarginMode(data.config.margin_mode || "isolated");
          setRisk((data.config.risk_per_trade || 0.01) * 100);
        }
      }
    } catch (e) {
      console.error(e);
      setLastError("API Connection Error");
    }
  };

  const fetchTickers = async () => {
    try {
      console.log("Fetching tickers...");
      const res = await fetch("http://127.0.0.1:8000/tickers");
      if (res.ok) {
        const data = await res.json();
        console.log("Tickers received:", Object.keys(data).length);
        setTickers(data);
      }
    } catch (e) { console.error("Tickers error:", e); }
  };

  const fetchOrderBook = async () => {
    try {
      console.log("Fetching order book for:", symbol);
      const res = await fetch(`http://127.0.0.1:8000/orderbook?symbol=${encodeURIComponent(symbol)}&limit=18`);
      if (res.ok) {
        const data = await res.json();
        console.log("Order Book received:", data.bids?.length, "bids");
        setOrderBook(data);
      }
    } catch (e) { console.error("OrderBook error:", e); }
  };

  const updateConfig = async (partialConfig: any) => {
    try {
      // Merge current local state with updates
      const fullConfig = {
        symbol,
        leverage,
        margin_mode: marginMode,
        risk_per_trade: risk / 100,
        ...partialConfig
      };

      await fetch("http://127.0.0.1:8000/bot/config", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(fullConfig)
      });
      fetchStatus();
    } catch (e) { console.error(e); }
  };

  const handleStartBot = async () => {
    try {
      setLastError(null);
      // 1. Send Config First
      await fetch("http://127.0.0.1:8000/bot/config", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          symbol,
          leverage,
          margin_mode: marginMode,
          risk_per_trade: risk / 100
        }),
      });

      // 2. Start
      setBotStatus("online"); // Optimistic update
      const res = await fetch("http://127.0.0.1:8000/bot/start", { method: "POST" });
      if (res.ok) {
        console.log("Bot started successfully");
        fetchStatus();
      } else {
        setBotStatus("offline");
        setLastError("Bot failed to start");
      }
    } catch (e) { setLastError("Failed to start bot"); }
  };

  const handleStopBot = async () => {
    try {
      setLastError(null);
      setBotStatus("offline"); // Optimistic update
      const res = await fetch("http://127.0.0.1:8000/bot/stop", { method: "POST" });
      if (res.ok) {
        console.log("Bot stopped successfully");
        fetchStatus();
      } else {
        setBotStatus("online");
        setLastError("Bot failed to stop");
      }
    } catch (e) { setLastError("Failed to stop bot"); }
  };
  useEffect(() => {
    setIsMounted(true);
    // 1. Initial Fetch to Sync State (Persistence)
    fetchStatus();

    // 1. Establish WebSocket Connection
    console.log("Opening WebSocket...");
    const ws = new WebSocket("ws://127.0.0.1:8000/ws");

    ws.onopen = () => console.log("✅ WebSocket Connected to Local Relay");
    ws.onerror = (e) => console.error("❌ WebSocket Error:", e);
    ws.onclose = () => console.warn("⚠️ WebSocket Disconnected");

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        // console.log("WS Data Received:", data.e, data.s); // Too noisy for prod, keep for debug if needed

        // Handle Ticker Update
        if (data.e === "24hrTicker") {
          const s = data.s; // e.g., BTCUSDT
          // Convert back to our format if possible
          const displaySymbol = s.includes('USDT') ? s.replace('USDT', '/USDT') : s;

          setTickers(prev => ({
            ...prev,
            [displaySymbol]: {
              last: parseFloat(data.c),
              percentage: parseFloat(data.P),
              high: parseFloat(data.h),
              low: parseFloat(data.l)
            }
          }));
        }

        // Handle Depth Update (Order Book)
        if (data.e === "depthUpdate") {
          const s = data.s;
          const displaySymbol = s.includes('USDT') ? s.replace('USDT', '/USDT') : s;

          if (displaySymbol === symbol) {
            setOrderBook({
              bids: data.b,
              asks: data.a
            });
          }
        }
      } catch (err) {
        console.error("WS Parse Error:", err);
      }
    };

    // 2. Initial Fetch + Fallback/Slow Polling
    fetchTickers();
    fetchOrderBook();
    const interval = setInterval(() => {
      fetchStatus();
    }, 5000);

    return () => {
      clearInterval(interval);
      ws.close();
    };
  }, [symbol]);

  return (
    <div className="flex flex-col h-screen overflow-hidden text-[13px] font-sans selection:bg-primary/30 bg-background text-foreground">

      {/* 1. Top Ticker Bar */}
      <div className="flex items-center h-8 bg-[#1e2329] border-b border-accent px-4 gap-6 overflow-x-auto no-scrollbar scroll-smooth">
        {Object.entries(tickers).map(([s, data]) => (
          <div
            key={s}
            className={`flex gap-2 whitespace-nowrap group cursor-pointer px-2 py-1 rounded transition-colors ${symbol === s ? 'bg-accent/50' : 'hover:bg-accent/20'}`}
            onClick={() => {
              setSymbol(s);
              updateConfig({ symbol: s });
            }}
          >
            <span className="font-medium text-foreground group-hover:text-primary transition-colors">{s.replace('/', '')}</span>
            <span className={data.percentage >= 0 ? "text-success" : "text-danger"}>
              {data.last.toLocaleString()}
            </span>
            <span className={`text-[11px] ${data.percentage >= 0 ? "text-success" : "text-danger"}`}>
              {data.percentage > 0 ? "+" : ""}{data.percentage.toFixed(2)}%
            </span>
          </div>
        ))}
      </div>

      {/* 2. Main Header / Symbol Info */}
      <header className="flex items-center h-14 bg-card border-b border-accent px-4 gap-8 shrink-0">
        <div className="flex items-center gap-3 min-w-[140px]">
          <h1 className="text-xl font-bold tracking-tight">{symbol.replace('/', '')}</h1>
          <span className="text-[10px] px-1 py-0.5 bg-accent rounded text-muted font-bold">PERP</span>
        </div>

        <div className="flex gap-8 overflow-hidden items-center">
          <div className="flex flex-col">
            <span className="text-muted text-[11px] leading-tight">Price</span>
            <span className="text-success font-bold text-sm tracking-tight">{tickers[symbol]?.last?.toLocaleString() || "---"}</span>
          </div>
          <div className="flex flex-col">
            <span className="text-muted text-[11px] leading-tight">24h Change</span>
            <span className={`font-medium ${tickers[symbol]?.percentage >= 0 ? "text-success" : "text-danger"}`}>
              {tickers[symbol]?.percentage ? `${tickers[symbol].percentage > 0 ? '+' : ''}${tickers[symbol].percentage.toFixed(2)}%` : "0.00%"}
            </span>
          </div>
          <div className="hidden md:flex flex-col">
            <span className="text-muted text-[11px] leading-tight">24h High</span>
            <span className="font-medium">{tickers[symbol]?.high?.toLocaleString() || "---"}</span>
          </div>
          <div className="hidden md:flex flex-col">
            <span className="text-muted text-[11px] leading-tight">24h Low</span>
            <span className="font-medium">{tickers[symbol]?.low?.toLocaleString() || "---"}</span>
          </div>
        </div>

        <div className="flex-1" />

        <div className="flex items-center gap-4">
          {botStatus === 'online' && (
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-success/10 border border-success/30 animate-pulse">
              <div className="w-2 h-2 rounded-full bg-success shadow-[0_0_8px_#0ecb81]" />
              <span className="text-[10px] font-black uppercase text-success tracking-tighter">Auto-trading Active</span>
            </div>
          )}
          <div className="flex items-center gap-2 px-3 py-1.5 rounded bg-accent/30 border border-accent/50 shadow-inner">
            <div className={`w-1.5 h-1.5 rounded-full ${botStatus === 'online' ? 'bg-success shadow-[0_0_8px_#0ecb81]' : 'bg-muted'}`} />
            <span className="uppercase font-extrabold text-[11px] tracking-wider">{botStatus}</span>
          </div>
        </div>
      </header>

      {/* 3. Main Workspace */}
      <main className="flex-1 flex overflow-hidden">

        {/* Left: Order Book (Sidebar) */}
        <aside className="w-72 bg-card border-r border-[#2b3139] flex flex-col hidden lg:flex">
          <div className="p-3 border-b border-accent h-10 flex items-center justify-between">
            <span className="font-bold uppercase text-[11px] tracking-wider text-muted">Order Book</span>
            <div className="flex gap-1">
              <div className="w-3 h-3 bg-success rounded-sm opacity-50" />
              <div className="w-3 h-3 bg-danger rounded-sm opacity-50" />
            </div>
          </div>
          <div className="flex-1 overflow-hidden flex flex-col font-mono">
            {/* Headers */}
            <div className="flex px-3 py-1 text-[10px] text-muted border-b border-accent/50">
              <span className="flex-1">Price(USDT)</span>
              <span>Size({symbol.split('/')[0]})</span>
            </div>
            {/* Asks (Sell) */}
            <div className="flex-1 flex flex-col-reverse justify-end overflow-hidden py-1">
              {isMounted && (orderBook.asks.length > 0 ? orderBook.asks.slice(0, 18).map((ask, i) => (
                <div key={i} className="flex px-3 py-0.5 text-[11px] relative group hover:bg-white/5 cursor-pointer">
                  <div className="absolute right-0 top-0 bottom-0 bg-danger/10 transition-all duration-500" style={{ width: `${Math.min(100, (parseFloat(ask[1]) / (Math.max(...orderBook.asks.map(a => parseFloat(a[1]))) || 1)) * 100)}%` }} />
                  <span className="flex-1 text-danger font-medium">{parseFloat(ask[0]).toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                  <span className="text-foreground z-10">{parseFloat(ask[1]).toFixed(3)}</span>
                </div>
              )) : [...Array(18)].map((_, i) => (
                <div key={i} className="flex px-3 py-0.5 text-[11px] relative animate-pulse opacity-20">
                  <span className="flex-1 text-danger">---</span>
                  <span className="text-foreground">---</span>
                </div>
              )))}
            </div>

            {/* Real-time Ticker */}
            <div className="py-2.5 px-3 border-y border-accent flex items-center justify-center bg-accent/10 shadow-inner group">
              <span className="text-xl font-black text-success tracking-tighter group-hover:scale-110 transition-transform">
                {tickers[symbol]?.last?.toLocaleString(undefined, { minimumFractionDigits: 2 }) || "0,000.00"}
              </span>
              <span className="ml-2 text-muted text-[10px] opacity-60">≈ ${tickers[symbol]?.last?.toLocaleString()}</span>
            </div>

            {/* Bids (Buy) */}
            <div className="flex-1 overflow-hidden py-1">
              {isMounted && (orderBook.bids.length > 0 ? orderBook.bids.slice(0, 18).map((bid, i) => (
                <div key={i} className="flex px-3 py-0.5 text-[11px] relative group hover:bg-white/5 cursor-pointer">
                  <div className="absolute right-0 top-0 bottom-0 bg-success/10 transition-all duration-500" style={{ width: `${Math.min(100, (parseFloat(bid[1]) / (Math.max(...orderBook.bids.map(b => parseFloat(b[1]))) || 1)) * 100)}%` }} />
                  <span className="flex-1 text-success font-medium">{parseFloat(bid[0]).toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
                  <span className="text-foreground z-10">{parseFloat(bid[1]).toFixed(3)}</span>
                </div>
              )) : [...Array(18)].map((_, i) => (
                <div key={i} className="flex px-3 py-0.5 text-[11px] relative animate-pulse opacity-20">
                  <span className="flex-1 text-success">---</span>
                  <span className="text-foreground">---</span>
                </div>
              )))}
            </div>
          </div>
        </aside>

        {/* Middle: Chart Area and Bottom Panel */}
        <section className="flex-1 flex flex-col min-w-0 bg-[#000]">
          {/* Main Chart Section */}
          <div className="flex-1 relative bg-[#0b0e11] flex flex-col overflow-hidden">
            {/* Toolbar */}
            <div className="h-9 border-b border-accent flex items-center px-4 gap-4 text-[11px] text-muted overflow-x-auto no-scrollbar shrink-0">
              <div className="flex items-center gap-1.5 border-r border-accent pr-4 mr-2">
                <span className="text-foreground font-bold hover:text-primary transition-colors cursor-pointer border-b-2 border-primary h-9 flex items-center px-1">Chart</span>
                <span className="hover:text-foreground transition-colors cursor-pointer h-9 flex items-center px-1">Depth</span>
              </div>
              <span className="hover:text-foreground cursor-pointer transition capitalize">Time 1H</span>
              <span className="hover:text-foreground cursor-pointer transition">Indicators</span>
              <span className="hidden sm:inline hover:text-foreground cursor-pointer transition opacity-50">Tools</span>
              <div className="ml-auto flex items-center gap-3">
                <span className="flex items-center gap-1"><div className="w-1.5 h-1.5 rounded-full bg-primary" /> Original</span>
                <span className="opacity-50">TradingView</span>
              </div>
            </div>

            {/* Styled Chart Placeholder -> REAL CHART */}
            <div className="flex-1 relative bg-[#0b0e11] flex flex-col overflow-hidden">
              <iframe
                key={`${symbol}-${botStatus}`}
                src={`https://s.tradingview.com/widgetembed/?symbol=BINANCE:${symbol.replace('/', '').toUpperCase()}.P&interval=60&theme=dark&style=1&timezone=Etc%2FUTC&withdateranges=true&hide_side_toolbar=false&allow_symbol_change=true&save_image=false&studies=%5B%5D`}
                className="w-full h-full border-none"
                style={{ minHeight: '400px' }}
              />
            </div>
          </div>

          {/* Bottom Panel (Positions/Orders) */}
          <div className="h-[240px] bg-card border-t border-[#2b3139] flex flex-col shrink-0">
            <div className="flex border-b border-accent px-4 h-10 items-center overflow-x-auto no-scrollbar">
              <button
                onClick={() => setActiveTab("positions")}
                className={`h-full px-4 text-[12px] whitespace-nowrap transition font-bold ${activeTab === 'positions' ? 'border-b-2 border-primary text-primary' : 'text-muted hover:text-foreground'}`}
              >
                Positions({positions.length})
              </button>
              <button
                onClick={() => setActiveTab("orders")}
                className={`h-full px-4 text-[12px] whitespace-nowrap transition font-bold ${activeTab === 'orders' ? 'border-b-2 border-primary text-primary' : 'text-muted hover:text-foreground'}`}
              >
                Open Orders({openOrders.length})
              </button>
              <button
                onClick={() => setActiveTab("assets")}
                className={`h-full px-4 text-[12px] whitespace-nowrap transition font-bold ${activeTab === 'assets' ? 'border-b-2 border-primary text-primary' : 'text-muted hover:text-foreground'}`}
              >
                Assets
              </button>
              <button className="h-full px-4 text-muted hover:text-foreground text-[12px] whitespace-nowrap transition">Order History</button>
              <button className="h-full px-4 text-muted hover:text-foreground text-[12px] whitespace-nowrap transition">Trade History</button>
            </div>

            <div className="flex-1 overflow-auto p-4 content-scrollbar">
              {activeTab === 'positions' && (
                <table className="w-full text-left text-[11px]">
                  <thead className="text-muted border-b border-accent uppercase">
                    <tr>
                      <th className="py-2 px-4">Symbol</th>
                      <th className="py-2 px-4">Size</th>
                      <th className="py-2 px-4">Entry Price</th>
                      <th className="py-2 px-4">Mark Price</th>
                      <th className="py-2 px-4">PNL (ROE%)</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-accent/30">
                    {positions.map((p, idx) => (
                      <tr key={idx} className="hover:bg-white/5 transition-colors">
                        <td className="py-2 px-4 font-bold">{p.symbol}</td>
                        <td className={`py-2 px-4 font-mono ${p.size > 0 ? "text-success" : "text-danger"}`}>{p.size}</td>
                        <td className="py-2 px-4">{p.entryPrice.toLocaleString()}</td>
                        <td className="py-2 px-4">{p.markPrice.toLocaleString()}</td>
                        <td className={`py-2 px-4 font-bold ${p.unrealizedProfit >= 0 ? "text-success" : "text-danger"}`}>
                          {p.unrealizedProfit >= 0 ? "+" : ""}{p.unrealizedProfit.toFixed(2)} USDT
                        </td>
                      </tr>
                    ))}
                    {positions.length === 0 && (
                      <tr>
                        <td colSpan={5} className="py-8 text-center text-muted italic">No active positions.</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              )}

              {activeTab === 'orders' && (
                <table className="w-full text-left text-[11px]">
                  <thead className="text-muted border-b border-accent uppercase">
                    <tr>
                      <th className="py-2 px-4">Time</th>
                      <th className="py-2 px-4">Symbol</th>
                      <th className="py-2 px-4">Type</th>
                      <th className="py-2 px-4">Side</th>
                      <th className="py-2 px-4">Price</th>
                      <th className="py-2 px-4">Amount</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-accent/30">
                    {openOrders.map((o, idx) => (
                      <tr key={idx} className="hover:bg-white/5 transition-colors">
                        <td className="py-2 px-4 text-muted">{new Date(o.updateTime).toLocaleTimeString()}</td>
                        <td className="py-2 px-4 font-bold">{o.symbol}</td>
                        <td className="py-2 px-4">{o.type}</td>
                        <td className={`py-2 px-4 font-bold ${o.side === 'BUY' ? "text-success" : "text-danger"}`}>{o.side}</td>
                        <td className="py-2 px-4">{parseFloat(o.price) || 'Market'}</td>
                        <td className="py-2 px-4">{o.origQty}</td>
                      </tr>
                    ))}
                    {openOrders.length === 0 && (
                      <tr>
                        <td colSpan={6} className="py-8 text-center text-muted italic">No open orders.</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              )}

              {activeTab === 'assets' && (
                <table className="w-full text-left text-[11px]">
                  <thead className="text-muted border-b border-accent uppercase">
                    <tr>
                      <th className="py-2 px-4">Asset</th>
                      <th className="py-2 px-4">Wallet Balance</th>
                      <th className="py-2 px-4">Unrealized PNL</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-accent/30">
                    {assets.map((a, idx) => (
                      <tr key={idx} className="hover:bg-white/5 transition-colors">
                        <td className="py-2 px-4 font-bold">{a.asset}</td>
                        <td className="py-2 px-4">{parseFloat(a.balance).toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
                        <td className={`py-2 px-4 ${a.unrealizedProfit >= 0 ? "text-success" : "text-danger"}`}>
                          {a.unrealizedProfit >= 0 ? "+" : ""}{parseFloat(a.unrealizedProfit).toFixed(2)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </div>
        </section>

        {/* Right: Order Form (Advanced Panel) */}
        <aside className="w-[320px] bg-card border-l border-[#2b3139] flex flex-col p-4 gap-5 overflow-y-auto no-scrollbar scroll-smooth">
          {/* USER SECTION: Manual Trade */}
          <div className="flex flex-col gap-4">
            <h4 className="font-black text-[12px] uppercase tracking-[0.2em] text-primary border-b border-accent/20 pb-2">Manual Trade</h4>

            {/* Margin/Leverage */}
            <div className="flex gap-2">
              <button
                onClick={() => { const next = marginMode === 'isolated' ? 'cross' : 'isolated'; setMarginMode(next); updateConfig({ margin_mode: next }); }}
                className="flex-1 py-1 bg-accent/60 rounded border border-accent hover:border-muted/30 font-bold transition-all uppercase text-[11px] tracking-wide"
              >
                {marginMode}
              </button>
              <button
                onClick={() => { const next = leverage >= 125 ? 1 : leverage + 5; setLeverage(next); updateConfig({ leverage: next }); }}
                className="flex-1 py-1 bg-accent/60 rounded border border-accent hover:border-muted/30 font-bold transition-all text-[11px] tracking-wide"
              >
                {leverage}x
              </button>
            </div>

            {/* Order Tabs */}
            <div className="flex gap-4 border-b border-accent/40 pb-2">
              <span className="text-primary font-bold border-b border-primary cursor-pointer pb-2 hover:opacity-80 transition text-[12px]">Limit</span>
              <span className="text-muted hover:text-foreground cursor-pointer transition text-[12px]">Market</span>
              <span className="text-muted hover:text-foreground cursor-pointer transition text-[12px]">Stop Limit</span>
            </div>

            {/* Inputs */}
            <div className="flex flex-col gap-4">
              <div className="flex justify-between items-center text-[11px]">
                <span className="text-muted">Available</span>
                <span className="text-foreground font-bold tracking-tight">{balance.toLocaleString()} <span className="text-muted font-normal text-[10px]">USDT</span></span>
              </div>
              <div className="relative group">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted text-[11px]">Price</span>
                <input className="w-full bg-input-bg border border-accent group-hover:border-muted/40 transition-all focus:border-primary rounded p-2 pl-14 pr-12 outline-none text-right font-bold text-sm" value={tickers[symbol]?.last?.toLocaleString() || ""} readOnly />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted text-[10px] font-bold">USDT</span>
              </div>
              <div className="relative group">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-muted text-[11px]">Size</span>
                <input
                  className="w-full bg-input-bg border border-accent group-hover:border-muted/40 transition-all focus:border-primary rounded p-2 pl-14 pr-12 outline-none text-right font-bold text-sm"
                  placeholder="0.00"
                  value={size}
                  onChange={(e) => setSize(e.target.value)}
                />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted text-[10px] font-bold uppercase">{symbol.split('/')[0]}</span>
              </div>
              <div className="flex justify-between px-1 mt-1 items-center relative py-4">
                <div className="absolute top-1/2 left-1 right-1 h-[2px] bg-accent" />
                {[0, 1, 2, 3, 4].map((i) => (
                  <div key={i} className="flex flex-col items-center gap-1.5 group cursor-pointer relative z-10">
                    <div className="w-3.5 h-3.5 rounded bg-accent border-2 border-card group-hover:bg-primary transition-colors hover:scale-125 shadow-lg" />
                  </div>
                ))}
              </div>

              <div className="flex gap-2.5 mt-2">
                <button
                  onClick={() => handleManualOrder("buy")}
                  className="flex-1 py-3 bg-success text-black font-extrabold rounded-md shadow-lg shadow-success/10 hover:bg-[#0fd086] active:scale-95 transition-all uppercase tracking-tighter text-sm"
                >
                  Buy/Long
                </button>
                <button
                  onClick={() => handleManualOrder("sell")}
                  className="flex-1 py-3 bg-danger text-black font-extrabold rounded-md shadow-lg shadow-danger/10 hover:bg-[#f84a62] active:scale-95 transition-all uppercase tracking-tighter text-sm"
                >
                  Sell/Short
                </button>
              </div>
            </div>
          </div>

          {/* USER SECTION: Algo Automation */}
          <div className="mt-6 pt-6 border-t-2 border-accent flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <h4 className="font-black text-[12px] uppercase tracking-[0.2em] text-primary">Algo Automation</h4>
              <div className={`w-2 h-2 rounded-full ${botStatus === 'online' ? 'bg-success animate-pulse' : 'bg-muted'}`} />
            </div>

            <div className="p-3 bg-accent/10 rounded border border-accent/30 flex flex-col gap-3">
              <div className="flex justify-between items-center">
                <span className="text-[11px] font-bold text-muted">Symbol</span>
                <select
                  className="bg-black/40 border border-accent rounded px-2 py-1 text-xs font-bold outline-none text-foreground cursor-pointer"
                  value={symbol}
                  onChange={(e) => {
                    const val = e.target.value;
                    setSymbol(val);
                    updateConfig({ symbol: val });
                  }}
                >
                  <option value="BTC/USDT">BTC/USDT</option>
                  <option value="ETH/USDT">ETH/USDT</option>
                  <option value="SOL/USDT">SOL/USDT</option>
                  <option value="BNB/USDT">BNB/USDT</option>
                </select>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[11px] font-bold text-muted">Leverage</span>
                <div className="flex items-center bg-black/40 border border-accent rounded p-0.5 gap-1">
                  {[1, 5, 10, 20].map(lv => (
                    <button
                      key={lv}
                      onClick={() => { setLeverage(lv); updateConfig({ leverage: lv }); }}
                      className={`px-2 py-0.5 rounded text-[10px] font-bold transition-all ${leverage === lv ? 'bg-primary text-black' : 'hover:bg-accent/30 text-muted'}`}
                    >
                      {lv}x
                    </button>
                  ))}
                </div>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-[11px] font-bold text-muted">Risk per Trade</span>
                <div className="flex items-center bg-black/40 border border-accent rounded px-2 py-1 gap-1">
                  <input
                    type="number"
                    className="w-12 bg-transparent text-right text-xs font-bold outline-none"
                    value={risk}
                    onChange={(e) => {
                      const val = parseFloat(e.target.value);
                      setRisk(val);
                      updateConfig({ risk_per_trade: val / 100 });
                    }}
                  />
                  <span className="text-[10px] font-bold text-muted">%</span>
                </div>
              </div>
              <div className="flex justify-between items-center opacity-60">
                <span className="text-[11px] font-bold text-muted">Stop Loss (ATR)</span>
                <span className="text-[11px]">Auto (Dynamic)</span>
              </div>
            </div>

            <button
              onClick={botStatus === 'online' ? handleStopBot : handleStartBot}
              className={`w-full py-4 rounded font-black text-sm transition-all uppercase tracking-widest shadow-xl transform active:scale-[0.98] ${botStatus === 'online'
                ? 'bg-danger text-white hover:bg-danger/90 shadow-danger/20'
                : 'bg-primary text-[#181a20] hover:bg-primary-hover shadow-primary/20'
                }`}
            >
              {botStatus === 'online' ? 'STOP AUTO-TRADING' : 'START AUTO-TRADING'}
            </button>

            {
              botStatus === 'online' && (
                <div className="text-center text-[10px] text-success font-mono animate-pulse">
                  Running Strategy: SmartFutures v1.2
                </div>
              )
            }
          </div>
        </aside>
      </main>

      {/* 4. Footer Status Bar */}
      <footer className="h-6 bg-[#181a20] border-t border-accent flex items-center px-4 justify-between text-[10px] text-muted shrink-0">
        <div className="flex items-center gap-5">
          <div className="flex items-center gap-1.5 text-success font-bold">
            <div className="w-1.5 h-1.5 bg-success rounded-full shadow-[0_0_5px_#0ecb81]" />
            STABLE CONNECTION
          </div>
          <span className="opacity-50 tracking-tighter">API PING: 12ms</span>
        </div>
        <div className="flex gap-5 font-bold">
          <span>UTC+05:30</span>
          <span className="hover:text-foreground cursor-pointer transition uppercase tracking-tighter">Cookie Preferences</span>
        </div>
      </footer>

      <style jsx>{`
    .no-scrollbar::-webkit-scrollbar { display: none; }
    .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
  `}</style>
    </div>
  );
}
